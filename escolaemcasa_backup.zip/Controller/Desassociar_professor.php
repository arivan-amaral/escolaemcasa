<?php
session_start();
include'../Model/Conexao.php';
include'../Model/Turma.php';
 try {

 	 $id=$_GET['id'];


 	 desassociar_professor($conexao, $id);
 	 //$_SESSION['status']=1;

 	 //header("location:../View/pesquisar_professor_associar.php?status=1");

 } catch (Exception $e) {
 	 //$_SESSION['status']=0;
    echo "VERIFIQUE SUA CONEXÃO COM A INTERNET!";
 	 //header("location:../View/pesquisar_professor_associar.php?status=0");

 	

 }



?>